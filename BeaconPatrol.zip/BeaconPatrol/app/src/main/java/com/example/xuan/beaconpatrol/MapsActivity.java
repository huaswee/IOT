package com.example.xuan.beaconpatrol;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.Toast;
import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import java.util.ArrayList;
import java.util.List;

public class MapsActivity extends AppCompatActivity
        implements OnMapReadyCallback, GoogleMap.OnInfoWindowClickListener {

    User user = new User();
    String name = user.getName();
    double amount = user.getAmount();
    int points = user.getPoints();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Retrieve the content view that renders the map.
        setContentView(R.layout.activity_maps);
        // Get the SupportMapFragment and request notification
        // when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
        User user = new User();
    }

    /**
     * Manipulates the map when it's available.
     * The API invokes this callback when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user receives a prompt to install
     * Play services inside the SupportMapFragment. The API invokes this method after the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        // Create an ArrayList of Marker objects and add them into the ArrayList
        List<Marker> markers = new ArrayList<Marker>();

        LatLng smu_sis = new LatLng(1.2973784, 103.8495219);
        markers.add(googleMap.addMarker(new MarkerOptions().position(smu_sis).title("SMU SIS Capacity: 1/5")));

        LatLng smu_soa = new LatLng(1.2956192, 103.8498277);
        markers.add(googleMap.addMarker(new MarkerOptions().position(smu_soa).title("SMU SOA Capacity: 2/5")));

        LatLng smu_sob = new LatLng(1.2952545, 103.8505429);
        markers.add(googleMap.addMarker(new MarkerOptions().position(smu_sob).title("SMU SOB Capacity: 3/5")));

        LatLng smu_soe = new LatLng(1.2979327, 103.8489191);
        markers.add(googleMap.addMarker(new MarkerOptions().position(smu_soe).title("SMU SOE Capacity: 4/5")));

        LatLng smu_sol = new LatLng(1.2948224, 103.8495096);
        markers.add(googleMap.addMarker(new MarkerOptions().position(smu_sol).title("SMU SOL Capacity: 5/5")));

        // Zoom into Google Maps while fitting all markers inside
        final LatLngBounds.Builder builder = new LatLngBounds.Builder();
        for (Marker m : markers) {
            builder.include(m.getPosition());
        }
        LatLngBounds bounds = builder.build();

        final CameraUpdate cu = CameraUpdateFactory.newLatLngBounds(bounds, 500, 500, 0);
        googleMap.animateCamera(cu);

        googleMap.setOnInfoWindowClickListener(this);
    }

    public void onInfoWindowClick(Marker marker) {

        Toast.makeText(this, "Hi " + name + ", you have $" + amount + " and " + points + " points.", Toast.LENGTH_LONG).show();

        new AlertDialog.Builder(this).setTitle("Confirmation")
                .setMessage("Do you want to lock your bike here?")
                .setIcon(android.R.drawable.ic_dialog_alert)
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                amount = user.getAmount() - 10.00;
                                points = user.getPoints() + 5;
                                Toast.makeText(MapsActivity.this, "Hi " + name + ", after locking you have $" + amount + " and " + points + " points.", Toast.LENGTH_LONG).show();
                            }
                        }).setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        }).show();


    }

}