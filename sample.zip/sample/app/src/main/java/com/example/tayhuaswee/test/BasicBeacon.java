package com.example.tayhuaswee.test;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.os.RemoteException;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

import org.altbeacon.beacon.Beacon;
import org.altbeacon.beacon.BeaconConsumer;
import org.altbeacon.beacon.BeaconManager;
import org.altbeacon.beacon.BeaconParser;
import org.altbeacon.beacon.Identifier;
import org.altbeacon.beacon.MonitorNotifier;
import org.altbeacon.beacon.RangeNotifier;
import org.altbeacon.beacon.Region;
import org.altbeacon.beacon.utils.UrlBeaconUrlCompressor;

import java.util.ArrayList;
import java.util.Collection;

public class BasicBeacon extends Activity implements BeaconConsumer {

    protected static final String TAG = "MonitoringActivity";
    private BeaconManager beaconManager;
    static final int MY_PERMISSIONS_REQUEST_Location = 1;
    static ArrayList<Identifier> identifiers = new ArrayList<Identifier>();
    static {
        identifiers.add(null);
    }
    static Region region = new Region("iot26",
            identifiers);
            //Identifier.parse("fda50693-a4e2-4fb1-afcf-c6eb07647825"), null, null);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_basic_beacon);
        Log.i(TAG, "\nEntering Get Location Permissions~~~\n");
        getLocationPermissions();
    }
    @Override
    protected void onDestroy() {
        super.onDestroy();
        beaconManager.unbind(this);
    }
    @Override
    public void onBeaconServiceConnect() {
        Log.i(TAG, "\nEntered OnBeaconServiceConnect!!!\n");
        beaconManager.addMonitorNotifier(new MonitorNotifier() {
            @Override
            public void didEnterRegion(Region region) {
                Log.d(TAG, "I detected a beacon in the region with namespace id " + region.getId1() +
                        " and instance id: " + region.getId2());
            }

            @Override
            public void didExitRegion(Region region) {
                Log.i(TAG, "\nI no longer see an beacon\n");
            }

            @Override
            public void didDetermineStateForRegion(int state, Region region) {
                Log.i(TAG, "\nI have just switched from seeing/not seeing beacons: " +state + "\n");
            }
        });

        beaconManager.addRangeNotifier(new RangeNotifier() {
            @Override
            public void didRangeBeaconsInRegion(Collection<Beacon> beacons, Region region) {
                if (beacons.size() > 0) {
                    Log.i(TAG, "The first beacon I see is about "+beacons.iterator().next().getDistance()+" meters away.");

                    Log.d(TAG, UrlBeaconUrlCompressor.uncompress(beacons.iterator().next().getId1().toByteArray()));
                }
            }
        });

        try {
            Log.i(TAG, "\nStarting Beacon Monitor...\n");

            beaconManager.startMonitoringBeaconsInRegion(region);
            beaconManager.startRangingBeaconsInRegion(region);
        } catch (RemoteException e) {
            Log.i(TAG, "\nREMOTE EXCEPTION OCCURED.\n");
        }
    }

    public void getLocationPermissions() {
        Log.i(TAG, "\nDisplaying Get Location Permissions...!!!\n");
        ActivityCompat.requestPermissions(this,
                new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                MY_PERMISSIONS_REQUEST_Location);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String permissions[], int[] grantResults) {
        Log.i(TAG, "\nEntered Permission Results!!!\nRequest Code = " + requestCode +
                " and My Location = " + MY_PERMISSIONS_REQUEST_Location + "\n" +
        "GrantResults.length = " + grantResults.length + " ");
        switch (requestCode) {
            case MY_PERMISSIONS_REQUEST_Location: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                    // permission was granted, yay! Do the
                    // contacts-related task you need to do.

                    Log.i(TAG, "\nInitializing BeaconManager...\n");
                    beaconManager = BeaconManager.getInstanceForApplication(this);
                    // To detect proprietary beacons, you must add a line like below corresponding to your beacon
                    // type.  Do a web search for "setBeaconLayout" to get the proper expression.
                    beaconManager.getBeaconParsers().clear();
                    beaconManager.getBeaconParsers().add(new BeaconParser().
                            setBeaconLayout(BeaconParser.EDDYSTONE_URL_LAYOUT));
                    beaconManager.getBeaconParsers().add(new BeaconParser().
                            setBeaconLayout(BeaconParser.EDDYSTONE_UID_LAYOUT));
                    beaconManager.getBeaconParsers().add(new BeaconParser().
                            setBeaconLayout(BeaconParser.EDDYSTONE_TLM_LAYOUT));
                            //setBeaconLayout("x,s:0-1=feaa,m:2-2=20,d:3-3,d:4-5,d:6-7,d:8-11,d:12-15"));
                    beaconManager.setForegroundScanPeriod(10000);
                    beaconManager.bind(this);
                    Log.i(TAG, "\nCompleted Initializing....\n");
                } else {

                    // permission denied, boo! Disable the
                    // functionality that depends on this permission.
                }
                return;
            }

            // other 'case' lines to check for other
            // permissions this app might request
        }
    }

}
