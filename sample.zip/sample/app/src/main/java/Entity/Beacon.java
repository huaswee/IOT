package Entity;

/**
 * Created by Tay Hua Swee on 01/11/2017.
 */

public class Beacon {

    String beaconID;
    String cord;
    static String sampleCord = "100,204";

    public Beacon(String beaconID) {
        this(beaconID, sampleCord);
    }

    public Beacon(String beaconID, String cord) {
        this.beaconID = beaconID;
        this.cord = cord;
    }


    public String getBeaconID() {
        return this.beaconID;
    }

    public void setBeaconID(String beaconID) {
        this.beaconID = beaconID;
    }

    public String getCord() {
        return this.cord;
    }

    public void setCord(String cord) {
        this.cord = cord;
    }

}
