package Controller;

import java.util.ArrayList;

import Entity.Lot;
import Entity.Bike;

/**
 * Created by Tay Hua Swee on 01/11/2017.
 */

public class DebugData {



    public ArrayList<Lot> getBeacons() {
        ArrayList<Lot> lotList = new ArrayList<Lot>();
        lotList.add(new Lot("beacon1"));
        lotList.add(new Lot("beacon2"));
        lotList.add(new Lot("beacon3"));
        lotList.add(new Lot("beacon4"));
        lotList.add(new Lot("beacon5"));

        return lotList;

    }

    public ArrayList<Bike> getBikes() {
        ArrayList<Bike> bikeList = new ArrayList<Bike>();
        bikeList.add(new Bike("bike1"));
        bikeList.add(new Bike("bike2"));
        bikeList.add(new Bike("bike3"));
        bikeList.add(new Bike("bike4"));
        bikeList.add(new Bike("bike5"));

        return bikeList;

    }

}
