package Controller;

import java.util.ArrayList;

import Entity.Beacon;
import Entity.Bike;

/**
 * Created by Tay Hua Swee on 01/11/2017.
 */

public class DebugData {



    public ArrayList<Beacon> getBeacons() {
        ArrayList<Beacon> beaconList = new ArrayList<Beacon>();
        beaconList.add(new Beacon("beacon1"));
        beaconList.add(new Beacon("beacon2"));
        beaconList.add(new Beacon("beacon3"));
        beaconList.add(new Beacon("beacon4"));
        beaconList.add(new Beacon("beacon5"));

        return beaconList;

    }

    public ArrayList<Bike> getBikes() {
        ArrayList<Bike> bikeList = new ArrayList<Bike>();
        bikeList.add(new Bike("bike1"));
        bikeList.add(new Bike("bike2"));
        bikeList.add(new Bike("bike3"));
        bikeList.add(new Bike("bike4"));
        bikeList.add(new Bike("bike5"));

        return bikeList;

    }

}
