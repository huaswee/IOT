package Controller;

import DAO.BeaconDAO;
import Entity.Lot;

/**
 * Created by Tay Hua Swee on 01/11/2017.
 */

public class BeaconDetect {

    public static void getBeaconID(String beaconID) {
        //where connection goes to

        Lot lot = BeaconDAO.getLot(beaconID);



    }

    public static void get


}
