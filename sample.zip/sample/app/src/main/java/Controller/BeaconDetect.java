package Controller;

/**
 * Created by Tay Hua Swee on 01/11/2017.
 */

public class BeaconDetect {

    public void getBeaconID() {
        //where connection goes to
    }


}
