package DAO;

/**
 * Created by Tay Hua Swee on 01/11/2017.
 */

public class BikeDAO {

    public static void getBikeData(String bikeID) {

    }

}
