package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 * Created by Tay Hua Swee on 01/11/2017.
 */

public class BeaconDAO {

    public static void getBeaconGPS(String beaconID) {
        try {
            Connection conn = ConnectionManager.getConnection();
            PreparedStatement smt = null;
            ResultSet rs = null;
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
