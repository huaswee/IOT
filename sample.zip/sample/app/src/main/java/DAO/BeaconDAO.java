package DAO;

import org.altbeacon.beacon.Beacon;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.HashMap;

import Entity.Lot;

/**
 * Created by Tay Hua Swee on 01/11/2017.
 */

public class BeaconDAO {
    private static final String getAllBeaconSmt = "Select * from Beacon";
    private static HashMap<String, Lot> lotMap = new HashMap<String, Lot>();

    public static void getAllLotData() {
        try {
            Connection conn = ConnectionManager.getConnection();
            PreparedStatement smt = conn.prepareStatement(getAllBeaconSmt);
            ResultSet rs = smt.executeQuery();

            while (rs.last()) {
                String id = rs.getString(1);
                String cord = rs.getString(2);

                Lot lot = new Lot(id, cord);

                    lotMap.put(id, lot);

            }

        } catch (Exception e) {
            e.printStackTrace();
        }


    }

    public static Lot getLot (String beaconID) {
        return lotMap.get(beaconID);

    }

    public static void putLot(String beaconID, String cord) {
        Lot lot = new Lot(beaconID, cord);
        lotMap.put(beaconID, lot);
    }



}
